# Sweep — storage cleaner for Android

Scans your phone or tablet for leftover clutter, lists everything it finds by
category with sizes, and deletes only what you tick.

## Build (on the PC)

```bash
unzip Sweep.zip && cd Sweep
./build.sh
```

The script picks JDK 21/17 (offers to install `jdk21-openjdk` if missing),
downloads the Android SDK into `~/.local/share/android-sdk` on first run, and
produces `Sweep.apk`. If the device is plugged in with USB debugging on, it
offers to install it directly; otherwise copy the APK over and open it.

## What it finds

| Category | Ticked by default | Notes |
|---|---|---|
| Leftover app folders | yes | `Android/media/<pkg>` and root folders of uninstalled apps |
| Gallery trash | yes | `.trashed-*` files waiting in the recycle bin |
| Thumbnail caches | yes | `.thumbnails` folders — Android regenerates them |
| Logs & temp files | yes | `*.log`, `*.tmp`, `.cache` / `cache` folders |
| Empty folders | yes | standard folders (DCIM, Download, Camera…) are never touched |
| Installer files | only if the app is already installed | APK / XAPK / APKS / APKM |
| Duplicate files | no | SHA-256 match; the oldest copy is kept and never listed |
| Old downloads | no | in Download, unchanged for 90+ days |
| Large files | no | over 100 MB |
| App caches | — | needs Usage access; tap an app to open its page and clear cache |

Long-press any item to see its full path.

## Permissions

- **All files access** — required to scan shared storage (Android 11+).
- **Usage access** — optional, only for showing per-app cache sizes.
- Nothing is uploaded anywhere; the app has no internet permission.

## Limits (Android rules, not the app's)

- `Android/data` and `Android/obb` are locked to their own apps since Android 11, so
  leftovers there can't be seen without root.
- Other apps' caches can't be cleared by a normal app — Sweep shows the sizes and
  takes you to each app's settings page.
