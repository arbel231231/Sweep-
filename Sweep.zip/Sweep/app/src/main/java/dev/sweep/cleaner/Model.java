package dev.sweep.cleaner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** One thing the scanner found. */
final class Item {
    final int category;
    final File file;          // null for app-cache rows
    final String title;
    final String subtitle;
    final long size;
    final boolean isDir;
    boolean checked;
    String pkg;               // only for app-cache rows

    Item(int category, File file, String title, String subtitle, long size, boolean isDir, boolean checked) {
        this.category = category;
        this.file = file;
        this.title = title;
        this.subtitle = subtitle;
        this.size = size;
        this.isDir = isDir;
        this.checked = checked;
    }
}

/** A group of found items, e.g. "Thumbnail caches". */
final class Category {
    final int id;
    final String name;
    final String description;
    final boolean defaultChecked;
    final boolean deletable;
    final List<Item> items = new ArrayList<>();
    boolean expanded;

    Category(int id, String name, String description, boolean defaultChecked, boolean deletable) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.defaultChecked = defaultChecked;
        this.deletable = deletable;
    }

    long totalSize() {
        long t = 0;
        for (Item i : items) t += i.size;
        return t;
    }

    long selectedSize() {
        long t = 0;
        for (Item i : items) if (i.checked) t += i.size;
        return t;
    }

    int selectedCount() {
        int n = 0;
        for (Item i : items) if (i.checked) n++;
        return n;
    }

    boolean allChecked() {
        if (items.isEmpty()) return false;
        for (Item i : items) if (!i.checked) return false;
        return true;
    }

    void setAll(boolean checked) {
        for (Item i : items) i.checked = checked;
    }
}
