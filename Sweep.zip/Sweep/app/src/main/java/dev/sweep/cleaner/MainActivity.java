package dev.sweep.cleaner;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.StatFs;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.text.format.Formatter;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_STORAGE = 1;

    // Palette
    private int cBg, cSurface, cSurface2, cText, cSub, cAccent, cOnAccent, cDivider;
    private boolean night;

    private TextView storageText, statusText, pathText, cleanBtn, scanBtn;
    private ProgressBar storageBar, spinner;
    private LinearLayout permCard, usageCard, bottomBar;
    private ListView list;
    private RowAdapter adapter;

    private Category[] cats;
    private Scanner scanner;
    private boolean busy;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // ------------------------------------------------------------------ setup

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupPalette();
        setContentView(buildLayout());
        refreshStorage();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionCards();
        refreshStorage();
    }

    @Override
    protected void onDestroy() {
        if (scanner != null) scanner.cancelled = true;
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshPermissionCards();
    }

    private void setupPalette() {
        night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            cBg = 0xFF0F1113; cSurface = 0xFF191C20; cSurface2 = 0xFF15181B;
            cText = 0xFFECEEF0; cSub = 0xFF98A1AA; cAccent = 0xFF4FD1A5; cOnAccent = 0xFF06261B;
            cDivider = 0xFF262A2F;
        } else {
            cBg = 0xFFF4F5F6; cSurface = 0xFFFFFFFF; cSurface2 = 0xFFFAFBFB;
            cText = 0xFF15181B; cSub = 0xFF5D666F; cAccent = 0xFF0E9F74; cOnAccent = 0xFFFFFFFF;
            cDivider = 0xFFE4E7EA;
        }
    }

    private View buildLayout() {
        LinearLayout rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setBackgroundColor(cBg);
        rootView.setFitsSystemWindows(true);

        // Header
        LinearLayout header = vertical();
        header.setPadding(dp(20), dp(18), dp(20), dp(8));
        TextView title = text("Sweep", 28, cText, true);
        header.addView(title);
        storageText = text("", 14, cSub, false);
        storageText.setPadding(0, dp(4), 0, dp(8));
        header.addView(storageText);
        storageBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        storageBar.setMax(1000);
        storageBar.setProgressTintList(ColorStateList.valueOf(cAccent));
        storageBar.setProgressBackgroundTintList(ColorStateList.valueOf(cDivider));
        header.addView(storageBar, new LinearLayout.LayoutParams(-1, dp(6)));
        rootView.addView(header);

        // Permission card
        permCard = card(
                "Allow access to files",
                "Sweep needs “All files access” to look through your storage. Nothing leaves your device.",
                "Allow", v -> requestStorage(), null, null);
        rootView.addView(permCard, cardParams());

        // Usage-access card (optional, unlocks app cache sizes)
        usageCard = card(
                "See which apps hog cache (optional)",
                "Grant “Usage access” so Sweep can show each app's cache size.",
                "Grant", v -> openUsageSettings(),
                "Not now", v -> {
                    prefs().edit().putBoolean("hideUsage", true).apply();
                    refreshPermissionCards();
                });
        rootView.addView(usageCard, cardParams());

        // Scan row
        LinearLayout scanRow = new LinearLayout(this);
        scanRow.setOrientation(LinearLayout.HORIZONTAL);
        scanRow.setGravity(Gravity.CENTER_VERTICAL);
        scanRow.setPadding(dp(20), dp(10), dp(20), dp(6));
        scanBtn = pillButton("Scan", true);
        scanBtn.setOnClickListener(v -> {
            if (busy && scanner != null) scanner.cancelled = true;
            else if (!busy) startScan();
        });
        scanRow.addView(scanBtn, new LinearLayout.LayoutParams(-2, dp(44)));
        spinner = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        spinner.setIndeterminateTintList(ColorStateList.valueOf(cAccent));
        spinner.setVisibility(View.GONE);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(22), dp(22));
        sp.leftMargin = dp(14);
        scanRow.addView(spinner, sp);
        LinearLayout statusCol = vertical();
        statusText = text("Tap Scan to look for clutter.", 14, cText, false);
        pathText = text("", 12, cSub, false);
        pathText.setSingleLine(true);
        pathText.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        pathText.setVisibility(View.GONE);
        statusCol.addView(statusText);
        statusCol.addView(pathText);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(0, -2, 1);
        scp.leftMargin = dp(14);
        scanRow.addView(statusCol, scp);
        rootView.addView(scanRow);

        // Results
        list = new ListView(this);
        list.setDivider(new ColorDrawable(cDivider));
        list.setDividerHeight(Math.max(1, dp(1) / 2));
        list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        list.setClipToPadding(false);
        list.setPadding(0, dp(6), 0, dp(12));
        adapter = new RowAdapter();
        list.setAdapter(adapter);
        rootView.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        // Bottom bar
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setBackgroundColor(cSurface);
        bottomBar.setPadding(dp(16), dp(10), dp(16), dp(12));
        cleanBtn = pillButton("Clean", true);
        cleanBtn.setOnClickListener(v -> confirmClean());
        bottomBar.addView(cleanBtn, new LinearLayout.LayoutParams(-1, dp(50)));
        bottomBar.setVisibility(View.GONE);
        rootView.addView(bottomBar);

        return rootView;
    }

    // ------------------------------------------------------------ permissions

    private boolean hasStorage() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
        }
    }

    @SuppressWarnings("deprecation")
    private boolean hasUsageAccess() {
        AppOpsManager ops = getSystemService(AppOpsManager.class);
        if (ops == null) return false;
        int mode = Build.VERSION.SDK_INT >= 29
                ? ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName())
                : ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
        if (mode == AppOpsManager.MODE_DEFAULT) {
            return checkSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED;
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void openUsageSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            if (Build.VERSION.SDK_INT >= 29) i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            } catch (Exception e2) {
                toast("Couldn't open Usage access settings");
            }
        }
    }

    private void refreshPermissionCards() {
        boolean storage = hasStorage();
        permCard.setVisibility(storage ? View.GONE : View.VISIBLE);
        boolean showUsage = storage && !hasUsageAccess() && !prefs().getBoolean("hideUsage", false);
        usageCard.setVisibility(showUsage ? View.VISIBLE : View.GONE);
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("sweep", Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------------- scan

    private void startScan() {
        if (!hasStorage()) {
            requestStorage();
            return;
        }
        setBusy(true);
        cats = null;
        adapter.rebuild();
        updateBottomBar();
        statusText.setText("Scanning storage…");
        pathText.setText("");
        pathText.setVisibility(View.VISIBLE);
        scanBtn.setText("Stop");

        final boolean usage = hasUsageAccess();
        final Scanner s = new Scanner(getApplicationContext(), (message, path) -> ui.post(() -> {
            if (!busy) return;
            statusText.setText(message);
            pathText.setText(path);
        }));
        scanner = s;
        new Thread(() -> {
            Category[] result;
            try {
                result = s.run(usage);
            } catch (Throwable t) {
                result = null;
                final String err = t.toString();
                ui.post(() -> toast("Scan error: " + err));
            }
            final Category[] r = result;
            ui.post(() -> onScanDone(r, s.cancelled));
        }, "sweep-scan").start();
    }

    private void onScanDone(Category[] result, boolean stopped) {
        setBusy(false);
        scanBtn.setText("Scan again");
        pathText.setVisibility(View.GONE);
        cats = result;
        adapter.rebuild();
        updateBottomBar();
        updateSummary(stopped ? "Scan stopped — showing what was found so far." : null);
    }

    private void updateSummary(String prefix) {
        if (cats == null) {
            statusText.setText(prefix != null ? prefix : "Tap Scan to look for clutter.");
            return;
        }
        long total = 0, cache = 0;
        int count = 0;
        for (Category c : cats) {
            if (c.deletable) { total += c.totalSize(); count += c.items.size(); }
            else cache += c.totalSize();
        }
        StringBuilder sb = new StringBuilder();
        if (prefix != null) sb.append(prefix).append('\n');
        if (count == 0) {
            sb.append("Nothing to clean — your storage is tidy.");
        } else {
            sb.append("Found ").append(size(total)).append(" in ").append(count)
                    .append(count == 1 ? " item." : " items.");
        }
        if (cache > 0) sb.append("\nApp caches: ").append(size(cache)).append(" (clear from each app's page).");
        statusText.setText(sb.toString());
    }

    private void setBusy(boolean b) {
        busy = b;
        spinner.setVisibility(b ? View.VISIBLE : View.GONE);
        cleanBtn.setEnabled(!b);
        cleanBtn.setAlpha(b ? 0.4f : 1f);
    }

    // ------------------------------------------------------------------ clean

    private List<Item> selectedItems() {
        List<Item> out = new ArrayList<>();
        if (cats == null) return out;
        for (Category c : cats) {
            if (!c.deletable) continue;
            for (Item i : c.items) if (i.checked) out.add(i);
        }
        return out;
    }

    private void updateBottomBar() {
        List<Item> sel = selectedItems();
        boolean anyResults = false;
        if (cats != null) for (Category c : cats) if (c.deletable && !c.items.isEmpty()) anyResults = true;
        bottomBar.setVisibility(anyResults ? View.VISIBLE : View.GONE);
        long bytes = 0;
        for (Item i : sel) bytes += i.size;
        if (sel.isEmpty()) {
            cleanBtn.setText("Select items to clean");
            cleanBtn.setEnabled(false);
            cleanBtn.setAlpha(0.4f);
        } else {
            cleanBtn.setText("Clean " + size(bytes) + "  ·  " + sel.size() + (sel.size() == 1 ? " item" : " items"));
            cleanBtn.setEnabled(!busy);
            cleanBtn.setAlpha(busy ? 0.4f : 1f);
        }
    }

    private void confirmClean() {
        final List<Item> sel = selectedItems();
        if (sel.isEmpty() || busy) return;
        long bytes = 0;
        boolean review = false;
        for (Item i : sel) {
            bytes += i.size;
            int c = i.category;
            if (c == Scanner.LARGE || c == Scanner.DUPES || c == Scanner.OLD_DL || c == Scanner.APK) review = true;
        }
        String msg = "This frees about " + size(bytes) + ". Deleted files can't be recovered.";
        if (review) msg += "\n\nYour selection includes personal files (large files, duplicates, downloads or installers) — make sure you've checked them.";
        new AlertDialog.Builder(this)
                .setTitle("Delete " + sel.size() + (sel.size() == 1 ? " item?" : " items?"))
                .setMessage(msg)
                .setPositiveButton("Delete", (d, w) -> doClean(sel))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void doClean(final List<Item> sel) {
        setBusy(true);
        statusText.setText("Cleaning…");
        final Context app = getApplicationContext();
        new Thread(() -> {
            long freed = 0;
            int failed = 0;
            final List<Item> gone = new ArrayList<>();
            List<String> deletedPaths = new ArrayList<>();
            for (Item it : sel) {
                if (it.file == null) continue;
                if (Scanner.deleteRecursively(it.file, deletedPaths)) {
                    freed += it.size;
                    gone.add(it);
                } else {
                    failed++;
                }
            }
            // Let the gallery and other media apps forget the deleted files.
            if (!deletedPaths.isEmpty()) {
                List<String> toScan = deletedPaths.size() > 2000 ? deletedPaths.subList(0, 2000) : deletedPaths;
                MediaScannerConnection.scanFile(app, toScan.toArray(new String[0]), null, null);
            }
            final long f = freed;
            final int fail = failed;
            ui.post(() -> onCleanDone(gone, f, fail));
        }, "sweep-clean").start();
    }

    private void onCleanDone(List<Item> gone, long freed, int failed) {
        setBusy(false);
        if (cats != null) for (Item it : gone) cats[it.category].items.remove(it);
        adapter.rebuild();
        updateBottomBar();
        refreshStorage();
        String msg = "Freed " + size(freed) + ".";
        if (failed > 0) msg += " " + failed + (failed == 1 ? " item" : " items") + " couldn't be deleted.";
        updateSummary(msg);
    }

    // ---------------------------------------------------------------- storage

    private void refreshStorage() {
        try {
            StatFs fs = new StatFs(Environment.getExternalStorageDirectory().getPath());
            long total = fs.getTotalBytes();
            long free = fs.getAvailableBytes();
            long used = total - free;
            storageText.setText(size(used) + " used of " + size(total) + "  ·  " + size(free) + " free");
            storageBar.setProgress(total > 0 ? (int) (used * 1000 / total) : 0);
        } catch (Exception e) {
            storageText.setText("");
        }
    }

    // ------------------------------------------------------------------- list

    private final class RowAdapter extends BaseAdapter {
        private final List<Object> rows = new ArrayList<>();

        void rebuild() {
            rows.clear();
            if (cats != null) {
                for (Category c : cats) {
                    if (c.items.isEmpty()) continue;
                    rows.add(c);
                    if (c.expanded) rows.addAll(c.items);
                }
            }
            notifyDataSetChanged();
        }

        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int position) { return rows.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int position) { return rows.get(position) instanceof Category ? 0 : 1; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Object row = rows.get(position);
            if (row instanceof Category) return headerView((Category) row, (HeaderHolder) tagOf(convertView));
            return itemView((Item) row, (ItemHolder) tagOf(convertView));
        }

        private Object tagOf(View v) {
            return v == null ? null : v.getTag();
        }
    }

    private static final class HeaderHolder {
        View root; CheckBox box; TextView name, desc, meta, size, chevron; Category cat;
    }

    private static final class ItemHolder {
        View root; CheckBox box; TextView open, title, sub, size; Item item;
    }

    private View headerView(Category c, HeaderHolder h) {
        if (h == null) {
            h = new HeaderHolder();
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(12), dp(16), dp(12));
            row.setBackground(ripple(cSurface));
            row.setMinimumHeight(dp(64));

            h.box = checkBox();
            h.box.setClickable(true);
            h.box.setFocusable(false);
            row.addView(h.box, new LinearLayout.LayoutParams(dp(48), dp(48)));

            LinearLayout col = vertical();
            h.name = text("", 16, cText, true);
            h.desc = text("", 13, cSub, false);
            h.meta = text("", 12, cAccent, false);
            h.meta.setPadding(0, dp(2), 0, 0);
            col.addView(h.name);
            col.addView(h.desc);
            col.addView(h.meta);
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

            LinearLayout right = vertical();
            right.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            h.size = text("", 15, cText, true);
            h.size.setGravity(Gravity.END);
            h.chevron = text("", 14, cSub, false);
            h.chevron.setGravity(Gravity.END);
            right.addView(h.size);
            right.addView(h.chevron);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2);
            rp.leftMargin = dp(10);
            row.addView(right, rp);

            h.root = row;
            row.setTag(h);
            final HeaderHolder hh = h;
            row.setOnClickListener(v -> {
                hh.cat.expanded = !hh.cat.expanded;
                adapter.rebuild();
            });
            h.box.setOnClickListener(v -> {
                hh.cat.setAll(!hh.cat.allChecked());
                adapter.rebuild();
                updateBottomBar();
            });
        }
        h.cat = c;
        h.name.setText(c.name);
        h.desc.setText(c.description);
        int n = c.items.size();
        String count = n + (n == 1 ? " item" : " items");
        if (c.deletable) {
            int s = c.selectedCount();
            h.meta.setText(count + (s > 0 ? "  ·  " + s + " selected (" + size(c.selectedSize()) + ")" : ""));
            h.box.setVisibility(View.VISIBLE);
            h.box.setChecked(c.allChecked());
        } else {
            h.meta.setText(count + "  ·  tap an app to open its page");
            h.box.setVisibility(View.INVISIBLE);
        }
        h.size.setText(c.id == Scanner.EMPTY ? "—" : size(c.totalSize()));
        h.chevron.setText(c.expanded ? "Hide ▴" : "Show ▾");
        return h.root;
    }

    private View itemView(Item it, ItemHolder h) {
        if (h == null) {
            h = new ItemHolder();
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(20), dp(8), dp(16), dp(8));
            row.setBackground(ripple(cSurface2));
            row.setMinimumHeight(dp(56));

            h.box = checkBox();
            h.box.setClickable(false);
            h.box.setFocusable(false);
            row.addView(h.box, new LinearLayout.LayoutParams(dp(40), dp(40)));

            h.open = text("Open", 13, cAccent, true);
            h.open.setGravity(Gravity.CENTER);
            GradientDrawable pill = new GradientDrawable();
            pill.setCornerRadius(dp(14));
            pill.setStroke(dp(1), cAccent);
            h.open.setBackground(pill);
            h.open.setPadding(dp(10), dp(4), dp(10), dp(4));
            LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-2, -2);
            op.rightMargin = dp(6);
            row.addView(h.open, op);

            LinearLayout col = vertical();
            h.title = text("", 15, cText, false);
            h.title.setSingleLine(true);
            h.title.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            h.sub = text("", 12, cSub, false);
            h.sub.setMaxLines(2);
            h.sub.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(h.title);
            col.addView(h.sub);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
            cp.leftMargin = dp(4);
            row.addView(col, cp);

            h.size = text("", 13, cSub, false);
            h.size.setGravity(Gravity.END);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
            sp.leftMargin = dp(10);
            row.addView(h.size, sp);

            h.root = row;
            row.setTag(h);
            final ItemHolder hh = h;
            row.setOnClickListener(v -> {
                Item item = hh.item;
                if (item.category == Scanner.APP_CACHE) {
                    openAppPage(item.pkg);
                } else {
                    item.checked = !item.checked;
                    hh.box.setChecked(item.checked);
                    adapter.rebuild();
                    updateBottomBar();
                }
            });
            row.setOnLongClickListener(v -> {
                showDetails(hh.item);
                return true;
            });
        }
        h.item = it;
        boolean appCache = it.category == Scanner.APP_CACHE;
        h.box.setVisibility(appCache ? View.GONE : View.VISIBLE);
        h.open.setVisibility(appCache ? View.VISIBLE : View.GONE);
        h.box.setChecked(it.checked);
        h.title.setText(it.isDir ? it.title + "/" : it.title);
        h.sub.setText(it.subtitle);
        h.size.setText(it.category == Scanner.EMPTY ? "" : size(it.size));
        return h.root;
    }

    private void openAppPage(String pkg) {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null)));
            toast("Tap Storage → Clear cache");
        } catch (Exception e) {
            toast("Couldn't open the app's settings");
        }
    }

    private void showDetails(final Item it) {
        if (it.file == null) {
            openAppPage(it.pkg);
            return;
        }
        final String path = it.file.getAbsolutePath();
        String msg = path + "\n\nSize: " + (it.category == Scanner.EMPTY ? "empty" : size(it.size));
        long mod = it.file.lastModified();
        if (mod > 0) {
            msg += "\nModified: " + DateUtils.formatDateTime(this, mod,
                    DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR | DateUtils.FORMAT_SHOW_TIME);
        }
        new AlertDialog.Builder(this)
                .setTitle(it.title)
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .setNeutralButton("Copy path", (d, w) -> {
                    ClipboardManager cm = getSystemService(ClipboardManager.class);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("path", path));
                    toast("Path copied");
                })
                .show();
    }

    // ---------------------------------------------------------------- widgets

    private LinearLayout card(String title, String body, String action, View.OnClickListener onAction,
                              String secondary, View.OnClickListener onSecondary) {
        LinearLayout c = vertical();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cSurface);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), cDivider);
        c.setBackground(bg);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.addView(text(title, 16, cText, true));
        TextView b = text(body, 14, cSub, false);
        b.setPadding(0, dp(4), 0, dp(12));
        c.addView(b);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        TextView primary = pillButton(action, true);
        primary.setOnClickListener(onAction);
        buttons.addView(primary, new LinearLayout.LayoutParams(-2, dp(40)));
        if (secondary != null) {
            TextView sec = pillButton(secondary, false);
            sec.setOnClickListener(onSecondary);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(40));
            lp.leftMargin = dp(8);
            buttons.addView(sec, lp);
        }
        c.addView(buttons);
        c.setVisibility(View.GONE);
        return c;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(16), dp(8), dp(16), dp(4));
        return lp;
    }

    private TextView pillButton(String label, boolean filled) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(22), 0, dp(22), 0);
        b.setTextColor(filled ? cOnAccent : cAccent);
        GradientDrawable shape = new GradientDrawable();
        shape.setCornerRadius(dp(100));
        if (filled) shape.setColor(cAccent);
        else {
            shape.setColor(Color.TRANSPARENT);
            shape.setStroke(dp(1), cAccent);
        }
        GradientDrawable mask = new GradientDrawable();
        mask.setCornerRadius(dp(100));
        mask.setColor(Color.WHITE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(night ? 0x33FFFFFF : 0x22000000), shape, mask));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private Drawable ripple(int color) {
        return new RippleDrawable(ColorStateList.valueOf(night ? 0x22FFFFFF : 0x14000000),
                new ColorDrawable(color), new ColorDrawable(Color.WHITE));
    }

    private CheckBox checkBox() {
        CheckBox b = new CheckBox(this);
        int[][] states = {{android.R.attr.state_checked}, {}};
        b.setButtonTintList(new ColorStateList(states, new int[]{cAccent, cSub}));
        b.setGravity(Gravity.CENTER);
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private String size(long bytes) {
        return Formatter.formatShortFileSize(this, bytes);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
