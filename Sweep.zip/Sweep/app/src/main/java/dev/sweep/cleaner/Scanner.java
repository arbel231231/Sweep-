package dev.sweep.cleaner;

import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.os.Process;
import android.os.SystemClock;
import android.os.UserHandle;
import android.text.format.DateUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/** Walks shared storage and sorts what it finds into cleanup categories. */
final class Scanner {

    interface Listener {
        void onProgress(String message, String path);
    }

    static final int LEFTOVER = 0, TRASH = 1, THUMBS = 2, JUNK = 3, EMPTY = 4,
            APK = 5, DUPES = 6, OLD_DL = 7, LARGE = 8, APP_CACHE = 9;
    static final int COUNT = 10;

    private static final long MB = 1024L * 1024L;
    private static final long LARGE_FILE = 100 * MB;
    private static final long DUPE_MIN = MB;
    private static final long APP_CACHE_MIN = 5 * MB;
    private static final long OLD_AGE = 90L * DateUtils.DAY_IN_MILLIS;

    private static final Set<String> STANDARD_DIRS = new HashSet<>(Arrays.asList(
            "android", "dcim", "download", "downloads", "pictures", "music", "movies", "documents",
            "alarms", "notifications", "ringtones", "podcasts", "audiobooks", "recordings"));
    private static final Set<String> JUNK_DIRS = new HashSet<>(Arrays.asList(
            ".cache", "cache", ".tmp", ".temp", "debug_log"));
    private static final Set<String> JUNK_EXT = new HashSet<>(Arrays.asList("log", "tmp", "temp"));
    private static final Set<String> JUNK_NAMES = new HashSet<>(Arrays.asList(
            ".ds_store", "thumbs.db", "desktop.ini"));
    private static final Set<String> APK_EXT = new HashSet<>(Arrays.asList("apk", "xapk", "apks", "apkm"));
    private static final Set<String> TLDS = new HashSet<>(Arrays.asList(
            "com", "org", "net", "io", "de", "me", "app", "dev", "tv", "ru", "cn", "co", "uk",
            "jp", "fr", "it", "xyz", "info", "edu", "us", "in", "kr", "br", "il", "ai", "eu"));
    private static final Pattern PACKAGE = Pattern.compile("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$");

    /** Root-level folders some popular apps create, mapped to the packages that own them. */
    private static final Map<String, String[]> KNOWN_APP_DIRS = new HashMap<>();
    static {
        KNOWN_APP_DIRS.put("telegram", new String[]{"org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus", "org.thunderdog.challegram"});
        KNOWN_APP_DIRS.put("whatsapp", new String[]{"com.whatsapp", "com.whatsapp.w4b"});
        KNOWN_APP_DIRS.put("viber", new String[]{"com.viber.voip"});
        KNOWN_APP_DIRS.put("instagram", new String[]{"com.instagram.android"});
        KNOWN_APP_DIRS.put("signal", new String[]{"org.thoughtcrime.securesms"});
    }

    static Category[] newCategories() {
        Category[] c = new Category[COUNT];
        c[LEFTOVER] = new Category(LEFTOVER, "Leftover app folders", "Left behind by apps you've uninstalled", true, true);
        c[TRASH] = new Category(TRASH, "Gallery trash", "Deleted photos & videos still in the recycle bin", true, true);
        c[THUMBS] = new Category(THUMBS, "Thumbnail caches", "Preview images Android rebuilds on its own", true, true);
        c[JUNK] = new Category(JUNK, "Logs & temp files", "Log files, temp files and cache folders", true, true);
        c[EMPTY] = new Category(EMPTY, "Empty folders", "Folders with nothing inside", true, true);
        c[APK] = new Category(APK, "Installer files", "APK files you downloaded to install apps", false, true);
        c[DUPES] = new Category(DUPES, "Duplicate files", "Extra copies of identical files — the oldest copy is kept", false, true);
        c[OLD_DL] = new Category(OLD_DL, "Old downloads", "In Download and untouched for 90+ days", false, true);
        c[LARGE] = new Category(LARGE, "Large files", "Over 100 MB — review before deleting", false, true);
        c[APP_CACHE] = new Category(APP_CACHE, "App caches", "Android only lets you clear these in each app's settings", false, false);
        return c;
    }

    private final Context ctx;
    private final PackageManager pm;
    private final Listener listener;
    private final File root;
    private final String rootPath;
    private final File androidDir, mediaDir, dataDir, obbDir, downloadDir;
    private final Set<String> installed = new HashSet<>();
    private final Category[] cats = newCategories();
    private final Map<Long, List<File>> bySize = new HashMap<>();
    private final long now = System.currentTimeMillis();
    private int dirCount;
    private long lastPost;

    volatile boolean cancelled;

    Scanner(Context ctx, Listener listener) {
        this.ctx = ctx;
        this.pm = ctx.getPackageManager();
        this.listener = listener;
        this.root = Environment.getExternalStorageDirectory();
        this.rootPath = root.getAbsolutePath();
        this.androidDir = new File(root, "Android");
        this.mediaDir = new File(androidDir, "media");
        this.dataDir = new File(androidDir, "data");
        this.obbDir = new File(androidDir, "obb");
        this.downloadDir = new File(root, Environment.DIRECTORY_DOWNLOADS);
    }

    @SuppressWarnings("deprecation")
    Category[] run(boolean includeAppCaches) {
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (ApplicationInfo ai : apps) installed.add(ai.packageName);

        progress("Scanning storage…", rootPath, true);
        walk(root, 0);
        if (!cancelled) findDuplicates();
        if (!cancelled && includeAppCaches) scanAppCaches(apps);

        for (Category c : cats) {
            Collections.sort(c.items, (a, b) -> Long.compare(b.size, a.size));
        }
        return cats;
    }

    // ---------------------------------------------------------------- walking

    /** Returns true when this folder's whole tree holds no files and may be reported as empty. */
    private boolean walk(File dir, int depth) {
        if (cancelled || depth > 48) return false;
        File[] kids = dir.listFiles();
        if (kids == null) return false; // unreadable: never call it empty
        dirCount++;
        progress("Scanning storage… " + dirCount + " folders", dir.getAbsolutePath(), false);

        boolean empty = true;
        List<File> emptyKids = null;
        for (File f : kids) {
            if (cancelled) return false;
            if (isSymlink(f)) { empty = false; continue; }
            if (f.isDirectory()) {
                if (f.equals(dataDir) || f.equals(obbDir)) { empty = false; continue; }
                int claim = classifyDir(f, dir);
                if (claim >= 0) { addDir(claim, f); empty = false; continue; }
                if (walk(f, depth + 1)) {
                    if (emptyKids == null) emptyKids = new ArrayList<>();
                    emptyKids.add(f);
                } else {
                    empty = false;
                }
            } else {
                empty = false;
                classifyFile(f);
            }
        }

        if (empty && !isProtected(dir)) return true;
        if (emptyKids != null) {
            for (File e : emptyKids) {
                if (!isProtected(e)) {
                    add(new Item(EMPTY, e, e.getName(), rel(e.getParentFile()), 0, true, true));
                }
            }
        }
        return false;
    }

    private int classifyDir(File f, File parent) {
        String name = f.getName();
        String lower = name.toLowerCase(Locale.ROOT);
        if ((parent.equals(mediaDir) || parent.equals(root)) && looksLikePackage(name) && !installed.contains(name)) {
            return LEFTOVER;
        }
        if (parent.equals(root)) {
            String[] owners = KNOWN_APP_DIRS.get(lower);
            if (owners != null && !anyInstalled(owners)) return LEFTOVER;
        }
        if (lower.equals(".thumbnails")) return THUMBS;
        if (JUNK_DIRS.contains(lower)) return JUNK;
        return -1;
    }

    private void classifyFile(File f) {
        String name = f.getName();
        String lower = name.toLowerCase(Locale.ROOT);
        String ext = ext(lower);
        long len = f.length();

        if (lower.startsWith(".trashed-")) {
            add(new Item(TRASH, f, prettyTrashName(name), rel(f.getParentFile()), len, false, true));
        } else if (APK_EXT.contains(ext)) {
            addApk(f, len);
        } else if (JUNK_EXT.contains(ext) || JUNK_NAMES.contains(lower)) {
            add(new Item(JUNK, f, name, rel(f.getParentFile()), len, false, true));
        } else {
            long modified = f.lastModified();
            if (isUnder(f, downloadDir) && modified > 0 && now - modified > OLD_AGE) {
                String when = "Last changed " + DateUtils.getRelativeTimeSpanString(modified, now, DateUtils.DAY_IN_MILLIS);
                add(new Item(OLD_DL, f, name, when + " · " + rel(f.getParentFile()), len, false, false));
            } else if (len >= LARGE_FILE) {
                add(new Item(LARGE, f, name, rel(f.getParentFile()), len, false, false));
            }
            if (len >= DUPE_MIN) {
                List<File> group = bySize.get(len);
                if (group == null) { group = new ArrayList<>(2); bySize.put(len, group); }
                group.add(f);
            }
        }
    }

    private void addApk(File f, long len) {
        String sub = rel(f.getParentFile());
        boolean alreadyInstalled = false;
        try {
            PackageInfo info = pm.getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (info != null && info.packageName != null) {
                alreadyInstalled = installed.contains(info.packageName);
                sub = (alreadyInstalled ? "App is installed · " : "App not installed · ") + sub;
            }
        } catch (Exception ignored) {
        }
        add(new Item(APK, f, f.getName(), sub, len, false, alreadyInstalled));
    }

    private void addDir(int category, File dir) {
        long[] sc = new long[2]; // size, file count
        dirSize(dir, sc, 0);
        if (sc[1] == 0 && category != LEFTOVER) return; // an empty cache folder isn't worth listing
        String sub;
        if (category == LEFTOVER) {
            sub = "App no longer installed · " + files(sc[1]) + " · " + rel(dir.getParentFile());
        } else {
            sub = files(sc[1]) + " · " + rel(dir.getParentFile());
        }
        Category c = cats[category];
        add(new Item(category, dir, dir.getName(), sub, sc[0], true, c.defaultChecked));
    }

    private void dirSize(File dir, long[] out, int depth) {
        if (cancelled || depth > 48) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File f : kids) {
            if (isSymlink(f)) continue;
            if (f.isDirectory()) {
                dirSize(f, out, depth + 1);
            } else {
                out[0] += f.length();
                out[1]++;
            }
        }
    }

    // ------------------------------------------------------------- duplicates

    private void findDuplicates() {
        Set<String> alreadyListed = new HashSet<>();
        int groupsDone = 0;
        for (List<File> group : bySize.values()) {
            if (cancelled) return;
            if (group.size() < 2) continue;
            groupsDone++;
            progress("Comparing possible duplicates… " + groupsDone, group.get(0).getParent(), false);

            for (List<File> sameHead : groupBy(group, 64 * 1024)) {
                if (cancelled) return;
                for (List<File> same : groupBy(sameHead, Long.MAX_VALUE)) {
                    Collections.sort(same, (a, b) -> {
                        int c = Long.compare(a.lastModified(), b.lastModified());
                        return c != 0 ? c : Integer.compare(a.getAbsolutePath().length(), b.getAbsolutePath().length());
                    });
                    File keep = same.get(0);
                    for (int i = 1; i < same.size(); i++) {
                        File dupe = same.get(i);
                        add(new Item(DUPES, dupe, dupe.getName(),
                                "Same as " + rel(keep) + " · in " + rel(dupe.getParentFile()),
                                dupe.length(), false, false));
                        alreadyListed.add(dupe.getAbsolutePath());
                    }
                }
            }
        }
        // A duplicate is listed once, under Duplicates, rather than again as large/old.
        if (!alreadyListed.isEmpty()) {
            removeListed(cats[LARGE], alreadyListed);
            removeListed(cats[OLD_DL], alreadyListed);
        }
    }

    private static void removeListed(Category c, Set<String> paths) {
        for (int i = c.items.size() - 1; i >= 0; i--) {
            if (paths.contains(c.items.get(i).file.getAbsolutePath())) c.items.remove(i);
        }
    }

    /** Groups files by a hash of their first {@code limit} bytes; returns only groups of 2+. */
    private List<List<File>> groupBy(List<File> files, long limit) {
        Map<String, List<File>> map = new HashMap<>();
        for (File f : files) {
            if (cancelled) break;
            String h = hash(f, limit);
            if (h == null) continue;
            List<File> l = map.get(h);
            if (l == null) { l = new ArrayList<>(2); map.put(h, l); }
            l.add(f);
        }
        List<List<File>> out = new ArrayList<>();
        for (List<File> l : map.values()) if (l.size() > 1) out.add(l);
        return out;
    }

    private String hash(File f, long limit) {
        byte[] buf = new byte[64 * 1024];
        try (InputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            long left = limit;
            int n;
            while (left > 0 && (n = in.read(buf, 0, (int) Math.min(buf.length, left))) > 0) {
                md.update(buf, 0, n);
                left -= n;
                if (cancelled) return null;
            }
            byte[] d = md.digest();
            StringBuilder sb = new StringBuilder(d.length * 2);
            for (byte b : d) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------- app caches

    private void scanAppCaches(List<ApplicationInfo> apps) {
        StorageStatsManager ssm = ctx.getSystemService(StorageStatsManager.class);
        if (ssm == null) return;
        UserHandle user = Process.myUserHandle();
        int i = 0;
        for (ApplicationInfo ai : apps) {
            if (cancelled) return;
            i++;
            progress("Checking app caches… " + i + "/" + apps.size(), ai.packageName, false);
            try {
                StorageStats st = ssm.queryStatsForPackage(ai.storageUuid, ai.packageName, user);
                long cache = st.getCacheBytes();
                if (cache >= APP_CACHE_MIN) {
                    String label = String.valueOf(pm.getApplicationLabel(ai));
                    Item it = new Item(APP_CACHE, null, label, ai.packageName, cache, false, false);
                    it.pkg = ai.packageName;
                    add(it);
                }
            } catch (Exception ignored) {
                // Package vanished, or usage access was revoked mid-scan.
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private void add(Item item) {
        cats[item.category].items.add(item);
    }

    private boolean isProtected(File d) {
        if (d.equals(root)) return true;
        String p = d.getAbsolutePath();
        String a = androidDir.getAbsolutePath();
        if (p.equals(a) || p.startsWith(a + "/")) return true;
        File parent = d.getParentFile();
        if (parent != null && parent.equals(root) && STANDARD_DIRS.contains(d.getName().toLowerCase(Locale.ROOT))) {
            return true;
        }
        String r = rel(d).toLowerCase(Locale.ROOT);
        return r.equals("dcim/camera") || r.equals("dcim/screenshots") || r.equals("pictures/screenshots");
    }

    private boolean anyInstalled(String[] pkgs) {
        for (String p : pkgs) if (installed.contains(p)) return true;
        return false;
    }

    private static boolean looksLikePackage(String name) {
        if (!PACKAGE.matcher(name).matches()) return false;
        int dots = 0;
        for (int i = 0; i < name.length(); i++) if (name.charAt(i) == '.') dots++;
        String first = name.substring(0, name.indexOf('.')).toLowerCase(Locale.ROOT);
        return dots >= 2 || TLDS.contains(first);
    }

    private static boolean isUnder(File f, File dir) {
        String d = dir.getAbsolutePath() + "/";
        return f.getAbsolutePath().toLowerCase(Locale.ROOT).startsWith(d.toLowerCase(Locale.ROOT));
    }

    private static boolean isSymlink(File f) {
        try {
            return Files.isSymbolicLink(f.toPath());
        } catch (Exception e) {
            return false;
        }
    }

    private static String ext(String lowerName) {
        int dot = lowerName.lastIndexOf('.');
        return dot > 0 ? lowerName.substring(dot + 1) : "";
    }

    /** ".trashed-1712345678-IMG_1234.jpg" → "IMG_1234.jpg" */
    private static String prettyTrashName(String name) {
        String rest = name.substring(".trashed-".length());
        int dash = rest.indexOf('-');
        return dash >= 0 && dash + 1 < rest.length() ? rest.substring(dash + 1) : name;
    }

    private static String files(long n) {
        return n == 1 ? "1 file" : n + " files";
    }

    /** Path relative to internal storage, e.g. "DCIM/.thumbnails". */
    String rel(File f) {
        if (f == null) return "";
        String p = f.getAbsolutePath();
        if (p.equals(rootPath)) return "Internal storage";
        if (p.startsWith(rootPath + "/")) return p.substring(rootPath.length() + 1);
        return p;
    }

    private void progress(String message, String path, boolean force) {
        long t = SystemClock.uptimeMillis();
        if (!force && t - lastPost < 120) return;
        lastPost = t;
        listener.onProgress(message, path);
    }

    // ---------------------------------------------------------------- deletion

    /** Deletes a file or a whole folder. Returns true if it is fully gone. */
    static boolean deleteRecursively(File f, List<String> deletedFiles) {
        if (isSymlink(f)) return f.delete();
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursively(k, deletedFiles);
            return f.delete() || !f.exists();
        }
        boolean ok = f.delete() || !f.exists();
        if (ok && deletedFiles != null) deletedFiles.add(f.getAbsolutePath());
        return ok;
    }
}
