#!/usr/bin/env bash
# Builds Sweep.apk on Arch / CachyOS. Run:  ./build.sh
# First run downloads the Android SDK (~600 MB) into ~/.local/share/android-sdk.
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/.local/share/android-sdk}}"
CMDLINE_ZIP="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"

say() { printf '\n\033[1;32m==>\033[0m %s\n' "$*"; }

# --- Java 17 or 21 (Gradle 8.14 can't run on the newest JDKs) ---------------
JAVA_HOME_PICK=""
for v in 21 17; do
  if [ -x "/usr/lib/jvm/java-$v-openjdk/bin/java" ]; then JAVA_HOME_PICK="/usr/lib/jvm/java-$v-openjdk"; break; fi
done
if [ -z "$JAVA_HOME_PICK" ]; then
  say "Need JDK 21 for the build (won't change your default Java)."
  read -r -p "Install jdk21-openjdk with pacman now? [Y/n] " ans
  if [[ "${ans:-Y}" =~ ^[Yy]$ ]]; then
    sudo pacman -S --needed jdk21-openjdk
    JAVA_HOME_PICK="/usr/lib/jvm/java-21-openjdk"
  else
    echo "Install it with:  sudo pacman -S jdk21-openjdk   then run ./build.sh again."; exit 1
  fi
fi
export JAVA_HOME="$JAVA_HOME_PICK"
export PATH="$JAVA_HOME/bin:$PATH"

for tool in curl unzip; do
  command -v "$tool" >/dev/null || { echo "Missing $tool — install it with: sudo pacman -S $tool"; exit 1; }
done

# --- Android SDK -------------------------------------------------------------
SDKMANAGER="$SDK/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKMANAGER" ]; then
  say "Downloading Android command-line tools to $SDK"
  tmp="$(mktemp -d)"
  curl -fL --progress-bar -o "$tmp/cmdline.zip" "$CMDLINE_ZIP"
  unzip -q "$tmp/cmdline.zip" -d "$tmp"
  mkdir -p "$SDK/cmdline-tools"
  rm -rf "$SDK/cmdline-tools/latest"
  mv "$tmp/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm -rf "$tmp"
fi

say "Accepting SDK licenses and installing build packages"
(yes 2>/dev/null || true) | "$SDKMANAGER" --sdk_root="$SDK" --licenses >/dev/null || true
"$SDKMANAGER" --sdk_root="$SDK" "platforms;android-34" "build-tools;34.0.0" "platform-tools" | grep -v '^\[' || true

echo "sdk.dir=$SDK" > local.properties

# --- Build -------------------------------------------------------------------
say "Building (first build downloads Gradle and takes a few minutes)"
./gradlew --no-daemon assembleRelease

cp app/build/outputs/apk/release/app-release.apk Sweep.apk
say "Done: $(pwd)/Sweep.apk"

# --- Optional: install straight to a USB-connected phone ---------------------
ADB="$SDK/platform-tools/adb"
if [ -x "$ADB" ] && "$ADB" get-state >/dev/null 2>&1; then
  read -r -p "A device is connected over USB. Install Sweep on it now? [Y/n] " ans
  if [[ "${ans:-Y}" =~ ^[Yy]$ ]]; then "$ADB" install -r Sweep.apk; fi
else
  echo "Copy Sweep.apk to your phone/tablet and open it to install."
fi
